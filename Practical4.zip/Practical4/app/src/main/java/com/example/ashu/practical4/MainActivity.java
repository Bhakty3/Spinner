package com.example.ashu.practical4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Spinner spin1,spin2,spin3;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spin1=(Spinner)findViewById(R.id.spin1);
        spin2=(Spinner)findViewById(R.id.spin2);
        spin3=(Spinner)findViewById(R.id.spin3);
        btn=(Button)findViewById(R.id.btn);

        spin1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                String select=adapterView.getItemAtPosition(i).toString();
                switch(select)
                {
                    case "Temperature":
                            spin2.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.temperature)));
                      break;

                    case "Length":
                        spin2.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.length)));
                        break;

                    case "Weight":
                        spin2.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.weight)));
                        break;

                    case "Volume":
                        spin2.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.volume)));
                        break;

                    case "Select Unit":
                        spin2.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.none)));
                        break;


                }

                spin2.setVisibility(View.VISIBLE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String select1=adapterView.getItemAtPosition(i).toString();
                switch(select1)
                {
                    case "Celsius":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.celsius)));
                        break;

                    case "Fahrenheit":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.fahrenheit)));
                        break;

                    case "Kelvin":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.kelvin)));
                        break;

                    case "Metre":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.metre)));
                        break;

                    case "Centimetre":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.centimetre)));
                        break;

                    case "Millimetre":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.millimetre)));
                        break;

                    case "Micrometre":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.micrometre)));
                        break;

                    case "Kilogram":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.kilogram)));
                        break;

                    case "Gram":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.gram)));
                        break;

                    case "Milligram":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.millimetre)));
                        break;

                    case "Microgram":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.microgram)));
                        break;

                    case "Litre":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.litre)));
                        break;


                    case "Millilitre":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.millilitre)));
                        break;


                    case "Cubic Metre":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.cubicmetre)));
                        break;


                    case "-":
                        spin3.setAdapter(new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.none)));
                        break;


                }

                spin3.setVisibility(View.VISIBLE);
            }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });




        spin3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text1 = spin2.getSelectedItem().toString();
                String text2 = spin3.getSelectedItem().toString();
                EditText txt=(EditText)findViewById(R.id.txt);
                double a=Double.parseDouble(String.valueOf(txt.getText()));
                //Toast.makeText(getApplicationContext(),text1,Toast.LENGTH_SHORT).show();

              double b;

             //   b=a*9/5+32;
               // Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                if(text1.equals("Celsius"))
                {
                    if(text2.equals("Fahrenheit"))
                    {
                        b=a*9/5+32;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Kelvin"))
                    {
                        b=a+273.15;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else if(text1.equals("Fahrenheit"))
                {
                    if(text2.equals("Celsius"))
                    {
                        b=(a-32)*5/9;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Kelvin"))
                    {
                        b=(a - 32)*5/9+273.15;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }


                else if(text1.equals("Kelvin"))
                {
                    if(text2.equals("Celsius"))
                    {
                        b=a-273.15;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Fahrenheit"))
                    {
                        b=(a- 273)*9/5+32;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else if(text1.equals("Metre"))
                {
                    if(text2.equals("Centimetre"))
                    {
                        b=a*100;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Millimetre"))
                    {
                        b=a*1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Micrometre"))
                    {
                        b=a*1000000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else if(text1.equals("Centimetre"))
                {
                    if(text2.equals("Metre"))
                    {
                        b=a/100;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Millimetre"))
                    {
                        b=a*10;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Micrometre"))
                    {
                        b=a*10000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }


                else if(text1.equals("Millimetre"))
                {
                    if(text2.equals("Metre"))
                    {
                        b=a/1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Centimetre"))
                    {
                        b=a/10;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Micrometre"))
                    {
                        b=a*1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }


                else if(text1.equals("Micrometre"))
                {
                    if(text2.equals("Metre"))
                    {
                        b=a/1000000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Centimetre"))
                    {
                        b=a/10000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Millimetre"))
                    {
                        b=a/1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else if(text1.equals("Kilogram"))
                {
                    if(text2.equals("Gram"))
                    {
                        b=a*1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Milligram"))
                    {
                        b=a*1000000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Microgram"))
                    {
                        b=a*1000000000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else if(text1.equals("Gram"))
                {
                    if(text2.equals("Kilogram"))
                    {
                        b=a/1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Milligram"))
                    {
                        b=a*1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Microgram"))
                    {
                        b=a*1000000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else if(text1.equals("Milligram"))
                {
                    if(text2.equals("Kilogram"))
                    {
                        b=a/1000000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Gram"))
                    {
                        b=a/1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Microgram"))
                    {
                        b=a*1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else if(text1.equals("Microgram"))
                {
                    if(text2.equals("Kilogram"))
                    {
                        b=a/1000000000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Gram"))
                    {
                        b=a/1000000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Milligram"))
                    {
                        b=a/1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else if(text1.equals("Litre"))
                {
                    if(text2.equals("Millilitre"))
                    {
                        b=a*1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Cubic Metre"))
                    {
                        b=a/1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else if(text1.equals("Millilitre"))
                {
                    if(text2.equals("Litre"))
                    {
                        b=a/1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Cubic Metre"))
                    {
                        b=a*1000000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else if(text1.equals("Cubic Metre"))
                {
                    if(text2.equals("Litre"))
                    {
                        b=a*1000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }
                    else if (text2.equals("Millilitre"))
                    {
                        b=a/1000000;
                        Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                    }

                }

                else
                {
                    Toast.makeText(getApplicationContext(),"Select Unit",Toast.LENGTH_SHORT).show();
                }
                //{
                 //   b=a*9/5+32;
                   // Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    //if(text2=="Fahrenheit")
                    //{
                      //  b=(a*(9/5))+32;
                        //Toast.makeText(getApplicationContext(),Double.toString(b),Toast.LENGTH_SHORT).show();
                    //}
                //}
                //else
                //{
                  //  Toast.makeText(getApplicationContext(),"Invalid",Toast.LENGTH_SHORT).show();
                //}

            }
        });


    }
}
